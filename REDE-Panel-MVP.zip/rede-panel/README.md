# REDE Panel (MVP)

Panel administrasi ringan untuk Ubuntu/Linux lama dengan Python 3.6. Fitur yang sudah tersedia:
- Login/logout dan penggantian password.
- Dashboard CPU, RAM, disk, jaringan, uptime, hostname, arsitektur.
- File manager terbatas ke `/var/www/rede-sites`: browse, editor teks maksimal 1 MB, upload, mkdir, delete file/folder kosong.
- Membuat catatan website + folder dan index.html, serta menyimpan port yang dipilih.
- Status deteksi perintah Docker dan MySQL/MariaDB.

## Batasan penting
- Ubuntu 17.10 sudah EOL dan tidak aman untuk server yang diekspos ke internet.
- Panel ini adalah MVP, bukan pengganti penuh aaPanel.
- Menu Website belum mengonfigurasi atau menjalankan Nginx/Apache secara otomatis.
- Menu Database hanya memeriksa apakah klien MySQL/MariaDB tersedia; pembuatan database belum diaktifkan.
- Menu Docker hanya memeriksa apakah Docker tersedia. Dukungan Docker pada i386 perlu diverifikasi terpisah.
- Aplikasi berjalan sebagai root melalui unit systemd agar dapat membaca statistik sistem; ini meningkatkan risiko. Gunakan hanya di LAN tepercaya. Untuk penggunaan jangka panjang, pindahkan operasi istimewa ke helper terbatas dan jalankan web app sebagai user khusus.
- Belum ada CSRF token, rate limiting login, atau HTTPS bawaan. Jangan expose ke internet.

## Instalasi
Jangan jalankan instalasi sebelum membaca batasan di atas.

```bash
unzip rede-panel.zip
cd rede-panel
sudo bash install.sh
```

Installer membutuhkan koneksi ke repositori APT dan pip. Pada Ubuntu 17.10 yang sudah EOL, `apt-get update` atau pemasangan paket dapat gagal karena repositori telah dipindahkan ke arsip. Jika demikian, hentikan dan perbaiki sumber repositori secara hati-hati; installer sengaja tidak mengubah `sources.list` otomatis.

Setelah berhasil:
- Buka `http://IP-SERVER:8888`
- Username awal: `admin` (kecuali ditentukan melalui `REDE_ADMIN_USER`)
- Password awal ditampilkan di output instalasi service. Ambil dengan:
  `sudo journalctl -u rede-panel -n 80 --no-pager`
- Ganti password di menu Pengaturan.

## Menjalankan sementara tanpa systemd
```bash
python3 app.py
```

## Direktori
- Aplikasi: direktori hasil ekstrak
- Data panel: `data/rede-panel.db`
- File website: `/var/www/rede-sites`
