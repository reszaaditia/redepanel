#!/bin/bash
set -e

if [ "$(id -u)" -ne 0 ]; then
  echo "Jalankan dengan sudo: sudo bash install.sh"
  exit 1
fi

ROOT="$(cd "$(dirname "$0")" && pwd)"
echo "== REDE Panel installer =="
echo "OS lama (Ubuntu 17.10 i386) terdeteksi. Paket APT mungkin tidak tersedia di repositori biasa."
echo "Installer ini tidak mengubah /etc/apt/sources.list secara otomatis."
echo

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 tidak ditemukan. Pasang Python 3 melalui repositori yang sesuai terlebih dahulu."
  exit 1
fi

PYVER="$(python3 -c 'import sys; print("%d.%d" % sys.version_info[:2])')"
echo "Python terdeteksi: $PYVER"
if [ "$PYVER" != "3.6" ]; then
  echo "Catatan: proyek diuji untuk sintaks Python 3.6, tetapi versi ini belum diuji di server kamu."
fi

apt-get update
apt-get install -y python3-pip python3-venv build-essential python3-dev

if [ ! -d "$ROOT/venv" ]; then
  python3 -m venv "$ROOT/venv"
fi
"$ROOT/venv/bin/pip" install --upgrade "pip<22"
"$ROOT/venv/bin/pip" install -r "$ROOT/requirements.txt"

mkdir -p /var/www/rede-sites "$ROOT/data"
chown -R root:root "$ROOT"
chmod 700 "$ROOT/data"
chmod +x "$ROOT/app.py"

cat > /etc/systemd/system/rede-panel.service <<EOF
[Unit]
Description=REDE Panel
After=network.target

[Service]
Type=simple
WorkingDirectory=$ROOT
Environment=REDE_HOST=0.0.0.0
Environment=REDE_PORT=8888
Environment=REDE_SITES_DIR=/var/www/rede-sites
ExecStart=$ROOT/venv/bin/python $ROOT/app.py
Restart=on-failure
RestartSec=5
User=root

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable rede-panel
systemctl restart rede-panel
echo
echo "REDE Panel dipasang."
echo "Buka: http://IP-SERVER:8888"
echo "Lihat kredensial awal: journalctl -u rede-panel -n 80 --no-pager"
echo "PENTING: ganti password setelah login. Jangan buka port ini langsung ke internet."
