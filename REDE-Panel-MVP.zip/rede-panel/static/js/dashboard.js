function setText(id, value) { var el = document.getElementById(id); if (el) el.textContent = value; }
function setBar(id, value) { var el = document.getElementById(id); if (el) el.style.width = Math.max(0, Math.min(100, value)) + "%"; }
function duration(seconds) {
  var d = Math.floor(seconds / 86400), h = Math.floor((seconds % 86400) / 3600);
  var m = Math.floor((seconds % 3600) / 60);
  return (d ? d + "h " : "") + h + "j " + m + "m";
}
async function refreshMetrics() {
  try {
    var response = await fetch("/api/metrics", {cache: "no-store", credentials: "same-origin"});
    if (!response.ok) throw new Error("HTTP " + response.status);
    var d = await response.json();
    setText("cpu", d.cpu); setBar("cpu-bar", d.cpu);
    setText("ram", d.ram_percent); setBar("ram-bar", d.ram_percent);
    setText("ram-detail", d.ram_used + " digunakan dari " + d.ram_total);
    setText("disk", d.disk_percent); setBar("disk-bar", d.disk_percent);
    setText("disk-detail", d.disk_used + " digunakan dari " + d.disk_total);
    setText("uptime", duration(d.uptime));
    setText("down", d.down_rate); setText("up", d.up_rate);
    setText("hostname", d.hostname); setText("platform", d.platform); setText("arch", d.architecture);
    setText("updated", "diperbarui " + new Date().toLocaleTimeString());
  } catch (e) { setText("updated", "koneksi metrik terputus"); }
}
refreshMetrics();
setInterval(refreshMetrics, 2000);
