#!/usr/bin/env python3
# REDE Panel MVP - compatible with Python 3.6
import os
import json
import time
import shutil
import socket
import sqlite3
import secrets
import subprocess
from functools import wraps
from pathlib import Path

from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_file, abort
from werkzeug.security import check_password_hash, generate_password_hash
import psutil

APP_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("REDE_DATA_DIR", str(APP_DIR / "data")))
SITES_DIR = Path(os.environ.get("REDE_SITES_DIR", "/var/www/rede-sites"))
DB_PATH = DATA_DIR / "rede-panel.db"
SECRET_FILE = DATA_DIR / "secret.key"
HOST = os.environ.get("REDE_HOST", "0.0.0.0")
PORT = int(os.environ.get("REDE_PORT", "8888"))

DATA_DIR.mkdir(parents=True, exist_ok=True)
SITES_DIR.mkdir(parents=True, exist_ok=True)

app = Flask(__name__)
if SECRET_FILE.exists():
    app.secret_key = SECRET_FILE.read_text().strip()
else:
    app.secret_key = secrets.token_hex(32)
    SECRET_FILE.write_text(app.secret_key)
    try:
        os.chmod(str(SECRET_FILE), 0o600)
    except OSError:
        pass

def db():
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = db()
    conn.execute("""CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS sites (
        id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL,
        port INTEGER UNIQUE NOT NULL, path TEXT NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    conn.commit()
    count = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    if count == 0:
        username = os.environ.get("REDE_ADMIN_USER", "admin")
        password = os.environ.get("REDE_ADMIN_PASSWORD")
        if not password:
            password = secrets.token_urlsafe(12)
            print("\\n[REDE Panel] Initial administrator credentials")
            print("Username: %s" % username)
            print("Password: %s" % password)
            print("Change this password after login.\\n")
        conn.execute("INSERT INTO users(username, password_hash) VALUES (?, ?)",
                     (username, generate_password_hash(password)))
        conn.commit()
    conn.close()

init_db()

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get("user_id"):
            return redirect(url_for("login", next=request.path))
        return fn(*args, **kwargs)
    return wrapped

def safe_path(relative):
    # File manager is intentionally confined to the website workspace.
    root = SITES_DIR.resolve()
    target = (root / relative.lstrip("/")).resolve()
    if target != root and root not in target.parents:
        abort(403)
    return target

def human_bytes(value):
    value = float(value)
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if value < 1024 or unit == "TB":
            return "%.1f %s" % (value, unit)
        value /= 1024.0

@app.after_request
def security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "SAMEORIGIN"
    response.headers["Referrer-Policy"] = "same-origin"
    response.headers["Cache-Control"] = "no-store"
    return response

@app.route("/")
def index():
    if not session.get("user_id"):
        return redirect(url_for("login"))
    return redirect(url_for("dashboard"))

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        conn = db()
        user = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        conn.close()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            return redirect(url_for("dashboard"))
        flash("Username atau password salah.", "error")
    return render_template("login.html")

@app.route("/logout", methods=["POST"])
@login_required
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/dashboard")
@login_required
def dashboard():
    return render_template("dashboard.html", username=session.get("username"))

@app.route("/api/metrics")
@login_required
def metrics():
    cpu = psutil.cpu_percent(interval=0.15)
    mem = psutil.virtual_memory()
    disk = psutil.disk_usage("/")
    net = psutil.net_io_counters()
    now = time.time()
    # Per-process network rates are not reliably available across all old psutil versions.
    if not hasattr(app, "_net_prev"):
        app._net_prev = (now, net.bytes_sent, net.bytes_recv)
    old_time, old_sent, old_recv = app._net_prev
    elapsed = max(now - old_time, 0.01)
    up_rate = max(0, net.bytes_sent - old_sent) / elapsed
    down_rate = max(0, net.bytes_recv - old_recv) / elapsed
    app._net_prev = (now, net.bytes_sent, net.bytes_recv)
    boot = psutil.boot_time()
    uptime = int(now - boot)
    return jsonify({
        "cpu": round(cpu, 1),
        "ram_percent": round(mem.percent, 1),
        "ram_used": human_bytes(mem.used),
        "ram_total": human_bytes(mem.total),
        "ram_available": human_bytes(mem.available),
        "disk_percent": round(disk.percent, 1),
        "disk_used": human_bytes(disk.used),
        "disk_total": human_bytes(disk.total),
        "disk_free": human_bytes(disk.free),
        "up_rate": human_bytes(up_rate) + "/s",
        "down_rate": human_bytes(down_rate) + "/s",
        "uptime": uptime,
        "hostname": socket.gethostname(),
        "platform": os.uname().sysname + " " + os.uname().release,
        "architecture": os.uname().machine
    })

@app.route("/files")
@login_required
def files():
    rel = request.args.get("path", "")
    target = safe_path(rel)
    if not target.exists() or not target.is_dir():
        flash("Folder tidak ditemukan.", "error")
        return redirect(url_for("files"))
    entries = []
    for item in sorted(target.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower())):
        entries.append({
            "name": item.name,
            "is_dir": item.is_dir(),
            "size": human_bytes(item.stat().st_size) if item.is_file() else "-",
            "rel": str(item.relative_to(SITES_DIR.resolve()))
        })
    parent = str(Path(rel).parent) if rel else ""
    if parent == ".":
        parent = ""
    return render_template("files.html", entries=entries, path=rel, parent=parent)

@app.route("/files/open")
@login_required
def file_open():
    rel = request.args.get("path", "")
    target = safe_path(rel)
    if not target.exists() or not target.is_file():
        abort(404)
    if target.stat().st_size > 1024 * 1024:
        flash("File lebih dari 1 MB tidak dibuka di editor web.", "error")
        return redirect(url_for("files", path=str(Path(rel).parent)))
    try:
        content = target.read_text(encoding="utf-8")
    except (UnicodeDecodeError, OSError):
        flash("File bukan teks UTF-8 atau tidak dapat dibaca.", "error")
        return redirect(url_for("files", path=str(Path(rel).parent)))
    return render_template("edit_file.html", path=rel, content=content)

@app.route("/files/save", methods=["POST"])
@login_required
def file_save():
    rel = request.form.get("path", "")
    target = safe_path(rel)
    if not target.exists() or not target.is_file():
        abort(404)
    content = request.form.get("content", "")
    if len(content.encode("utf-8")) > 1024 * 1024:
        flash("Ukuran file melebihi batas editor 1 MB.", "error")
        return redirect(url_for("file_open", path=rel))
    target.write_text(content, encoding="utf-8")
    flash("File berhasil disimpan.", "success")
    return redirect(url_for("file_open", path=rel))

@app.route("/files/mkdir", methods=["POST"])
@login_required
def files_mkdir():
    rel = request.form.get("path", "")
    name = request.form.get("name", "").strip()
    if not name or name in (".", "..") or "/" in name or "\\" in name:
        flash("Nama folder tidak valid.", "error")
        return redirect(url_for("files", path=rel))
    target = safe_path(str(Path(rel) / name))
    target.mkdir()
    flash("Folder dibuat.", "success")
    return redirect(url_for("files", path=rel))

@app.route("/files/upload", methods=["POST"])
@login_required
def files_upload():
    rel = request.form.get("path", "")
    upload = request.files.get("file")
    if not upload or not upload.filename:
        flash("Pilih file terlebih dahulu.", "error")
        return redirect(url_for("files", path=rel))
    name = os.path.basename(upload.filename)
    if name in ("", ".", ".."):
        abort(400)
    target = safe_path(str(Path(rel) / name))
    if target.exists():
        flash("File dengan nama itu sudah ada. Ganti nama file lalu coba lagi.", "error")
        return redirect(url_for("files", path=rel))
    upload.save(str(target))
    flash("Upload berhasil.", "success")
    return redirect(url_for("files", path=rel))

@app.route("/files/delete", methods=["POST"])
@login_required
def files_delete():
    rel = request.form.get("target", "")
    target = safe_path(rel)
    if target == SITES_DIR.resolve():
        abort(403)
    if not target.exists():
        abort(404)
    if target.is_dir():
        # No recursive deletion in this first release.
        if any(target.iterdir()):
            flash("Folder tidak kosong. Hapus isinya terlebih dahulu.", "error")
            return redirect(url_for("files", path=str(Path(rel).parent)))
        target.rmdir()
    else:
        target.unlink()
    flash("Item dihapus.", "success")
    return redirect(url_for("files", path=str(Path(rel).parent)))

@app.route("/websites", methods=["GET", "POST"])
@login_required
def websites():
    conn = db()
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        try:
            port = int(request.form.get("port", ""))
        except ValueError:
            port = 0
        if not name or len(name) > 60 or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_" for c in name):
            flash("Nama website hanya boleh berisi huruf, angka, tanda - dan _.", "error")
        elif port < 1024 or port > 65535:
            flash("Gunakan port antara 1024 sampai 65535.", "error")
        else:
            folder = SITES_DIR / name
            try:
                folder.mkdir()
                (folder / "index.html").write_text(
                    "<!doctype html><html><head><meta charset='utf-8'><title>%s</title></head>"
                    "<body><h1>%s</h1><p>Website dibuat melalui REDE Panel.</p></body></html>" % (name, name),
                    encoding="utf-8")
                conn.execute("INSERT INTO sites(name, port, path) VALUES (?, ?, ?)",
                             (name, port, str(folder)))
                conn.commit()
                flash("Folder website dibuat. Port disimpan, tetapi web server belum dikonfigurasi otomatis.", "success")
            except sqlite3.IntegrityError:
                flash("Nama atau port sudah digunakan.", "error")
            except OSError as exc:
                flash("Tidak bisa membuat folder: %s" % exc, "error")
    rows = conn.execute("SELECT * FROM sites ORDER BY id DESC").fetchall()
    conn.close()
    return render_template("websites.html", sites=rows)

@app.route("/databases")
@login_required
def databases():
    # This MVP shows database service status; database creation is not run as root automatically.
    try:
        result = subprocess.check_output(["bash", "-lc", "command -v mysql || command -v mariadb"], stderr=subprocess.STDOUT, universal_newlines=True).strip()
        installed = bool(result)
    except Exception:
        installed = False
    return render_template("databases.html", installed=installed)

@app.route("/docker")
@login_required
def docker():
    try:
        version = subprocess.check_output(["docker", "--version"], stderr=subprocess.STDOUT, universal_newlines=True).strip()
        installed = True
    except Exception:
        version = "Docker belum terpasang atau perintah tidak tersedia."
        installed = False
    return render_template("docker.html", installed=installed, version=version)

@app.route("/settings", methods=["GET", "POST"])
@login_required
def settings():
    if request.method == "POST":
        old = request.form.get("old_password", "")
        new = request.form.get("new_password", "")
        if len(new) < 12:
            flash("Password baru minimal 12 karakter.", "error")
        else:
            conn = db()
            user = conn.execute("SELECT * FROM users WHERE id = ?", (session["user_id"],)).fetchone()
            if user and check_password_hash(user["password_hash"], old):
                conn.execute("UPDATE users SET password_hash = ? WHERE id = ?",
                             (generate_password_hash(new), session["user_id"]))
                conn.commit()
                flash("Password berhasil diganti.", "success")
            else:
                flash("Password lama salah.", "error")
            conn.close()
    return render_template("settings.html")

@app.errorhandler(403)
def forbidden(_):
    return render_template("error.html", code=403, message="Akses ditolak."), 403

@app.errorhandler(404)
def not_found(_):
    return render_template("error.html", code=404, message="Halaman atau file tidak ditemukan."), 404

if __name__ == "__main__":
    print("REDE Panel listening on %s:%s" % (HOST, PORT))
    app.run(host=HOST, port=PORT, debug=False, threaded=True)
